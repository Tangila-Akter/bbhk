<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style>
    td:hover {
      background-color: #cdc9c9;
      color: #140a0a;
    }

    [type="search"] {
      outline-offset: -2px;
      -webkit-appearance: textfield;
      color: white !important;
    }

    .text {
      color: black;
    }

    .min-h-screen {
      min-height: 0vh !important;
    }
  </style>
</head>

<body>
  <div class="container-scroller">


    <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid page-body-wrapper">
      <div>
        <h1>Contact us</h1>
        <div style="position: relative; top:20px; right:4px;">

          <!--Notice View start-->
          <?php if(method_exists($data, 'links')): ?>


          <div class="d-flex justify-content-center">
            <?php echo $data->links(); ?>

          </div>
          <?php endif; ?>
          <form action="<?php echo e(url('noticesearch')); ?>" method="get" style="float:right; padding:10px; color:rgb(255, 255, 255);">
            <?php echo csrf_field(); ?>
            <div>
              <input class="form-control" type="search" name="search" placeholder="search"><input type="submit" value="search" class="btn btn-primary">

            </div>

          </form>
          <div class="id01 table-responsive-sm"></div>
          <table class="id01 table" style="margin-top: 8rem;">
            <thead>
              <tr class="table-success" style="color: black !important;">
                <th style="padding: 20px">Name</th>
                <th style="padding: 20px">Email</th>
                <th style="padding: 20px">Phone Number</th>
                <th style="padding: 20px">Message</th>
                <th style="padding: 20px">Action</th>
              </tr>
            </thead>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
              <tr style="background-color: #ffffff; color:black;" class="item">
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->email); ?></td>
                <td><?php echo e($data->phone); ?></td>
                <td><?php echo e($data->msg); ?></td>
                <td><a class="btn btn-warning" href="<?php echo e(url('/deletecontact',$data->id)); ?>">Delete</a></td>
              </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </table>



        </div>

      </div>

    </div>
    <?php if(method_exists($data, 'links')): ?>


    <div class="d-flex justify-content-center">
      <?php echo $data->links(); ?>

    </div>
    <?php endif; ?>
  </div>

  <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#table_id').DataTable();
    });
  </script>

</body>

</html><?php /**PATH F:\xampp\htdocs\bbhk\resources\views/admin/contact.blade.php ENDPATH**/ ?>
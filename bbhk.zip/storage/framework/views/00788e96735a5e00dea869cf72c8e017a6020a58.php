<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('user.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .icon {
        margin: 4px;
    }

    th {
        background-color: #65C178 !important;
        color: white;
        padding: 2px;

        height: 52px;
    }

    table {
        width: 96% !important;
    }

    .display {
        width: 100% !important;
    }
</style>

<body>
    <!-- Topbar Start -->
    <?php echo $__env->make('user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <?php echo $__env->make('user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navbar End -->

    <!-- Notice Start -->
    <div class="container py-3" id="Notice">
        <div class="row">
            <div class="col-md-12 mx-auto">
                <h4 class="text-secondary mb-3">Notice Board</h4>
                <?php if(method_exists($data, 'links')): ?>
                <div class="d-flex ">
                    <?php echo $data->links(); ?>

                </div>
                <?php endif; ?>
                <form action="<?php echo e(url('noticesearch')); ?>" method="get" class="form-inline" style="float:left;  ">
                    <?php echo csrf_field(); ?>
                    <input class="form-control" type="search" name="search" placeholder="search">
                    <input type="submit" value="search" class="btn btn-primary">
                </form><br>

                <table class="display">
                    <thead>
                        <tr>
                            <th>Notice</th>
                            <th>Date
                            </th>
                            <th>Download</th>
                        </tr>
                    </thead>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <td><a href="" target="_blank"> <?php echo e($data->title); ?></a>
                            </td>
                            <td><?php echo e($data->date); ?>

                            </td>
                            <td>
                                <a href="<?php echo e(url('notice_view')); ?>/<?php echo e($data->id); ?>" target="_blank rel=" noopener noreferrer" class="icon">
                                    <i class="fa fa-eye" align="center"></i></a>
                                <a href="<?php echo e(url('notice_download')); ?>/<?php echo e($data->filename); ?>" rel="noopener noreferrer" class="icon">
                                    <i class="fa fa-download" align="center"></i>
                                </a>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
    <!-- Notice End -->

    <!-- Footer Start -->
    <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <?php echo $__env->make('user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table_id').DataTable();
        });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\BBHK\resources\views/user/notice1.blade.php ENDPATH**/ ?>
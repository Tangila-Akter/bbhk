<div class="container-fluid">
    <div class="row ">
        <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-xxl-2">
            <a href="{{ url('home') }}">
                <img class="img_logo" src="school/Logo.png">
            </a>
        </div>
        <div class="col-sm-10 col-md-10 col-lg-10 col-xl-10 col-xxl-10 text-center ">
            <h1 style="color:#34A853; margin-top: 27px;">ভূঁইয়ার বাজার হনুফা খাতুন উচ্চ বিদ্যালয়</h1>
            <h4> স্থাপিতঃ ১৯৯৯ </h4>
            <h3> পোরকরা, সোনাইমুড়ী, নোয়াখালী </h3>
        </div>
    </div>
</div>